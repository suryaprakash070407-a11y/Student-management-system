# IronCore desktop app — Windows 10/11, 64-bit

## Install
Run `IronCore-Gym-Setup-1.1.1.exe`, choose an installation folder and finish. Open **IronCore Gym** from its desktop icon or Start menu. You do not need Node.js, a browser tab, a terminal or internet for normal use. The installer bundles Electron and the required application dependencies.

The application is unsigned. Only run a downloaded installer you trust. It has not been tested on a Windows machine in this build environment.

## Move your existing records
1. In your old browser version, use Settings → Download backup.
2. Close its terminal/server.
3. Open the new desktop app and create your owner username/password.
4. In Settings → Restore backup, choose the downloaded JSON file and confirm.
5. Check that your members, payments and attendance appear before retiring the old folder.

This imports records, not the old account password. Keep both the original folder and the backup until you have checked the import.

## Data location
Use **IronCore → Open data folder** to find the database. It is stored under your Windows profile's application-data directory, outside the installation folder. Updating/reinstalling the application does not intentionally remove gym data. Back up regularly to another drive.

## Behaviour
- Opens its own desktop window; the local backend starts automatically on a free loopback port.
- A second launch brings the existing window to the front.
- Closing the window stops the application and backend.
- Backup and CSV downloads open a Save dialog.
- HTML/CSS/JS screens and SQLite functionality are retained.
- The scanner remains a clearly labelled simulation until compatible hardware and a verified adapter are provided.
- Due totals remain scheduled renewal fees, not partial-payment balances.

## Developers / rebuilding
The source ZIP includes `Build-Windows-App.bat`. Install Node.js 24+, extract the ZIP, and run that file with internet access. It installs the locked dependencies and builds an installer in `dist`. Normal users should run the prebuilt installer instead.

Run `npm run desktop` to develop the desktop app, `npm start` for the legacy browser version, and `npm test` for isolated backend regression tests. If your npm configuration disables dependency install scripts, run `node node_modules/electron/install.js` before development startup.

Official packaging reference: https://www.electron.build/docs/nsis/
