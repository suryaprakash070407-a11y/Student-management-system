// Separate demonstration database; never seeds the normal gym database.
const path=require('node:path'),fs=require('node:fs');
process.env.DATA_DIR=path.join(__dirname,'demo-data-store');
process.env.PORT='3001';
const {db}=require('./server'),{fixtures}=require('./qa/fixtures');
if(!db.prepare('SELECT id FROM members LIMIT 1').get()){
 const f=fixtures();db.exec('BEGIN');
 try{for(const t of ['attendance','payments','members','plans','settings'])db.exec('DELETE FROM '+t);
 for(const t of ['plans','members','payments','attendance','settings'])for(const row of f[t]){const cols=Object.keys(row);db.prepare(`INSERT INTO ${t} (${cols.join(',')}) VALUES (${cols.map(()=>'?').join(',')})`).run(...Object.values(row));}
 db.exec('COMMIT');fs.writeFileSync(path.join(__dirname,'demo-records.json'),JSON.stringify(f,null,2));
 }catch(e){db.exec('ROLLBACK');throw e;}
}
console.log('DEMO ONLY: 24 fictional members. Open http://localhost:3001 and create a demo owner account. Normal gym records are unchanged.');
