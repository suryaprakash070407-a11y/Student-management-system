# Future biometric scanner integration

No scanner has been purchased. This build does not claim live fingerprint enrollment or matching. The Attendance demo is explicitly stored as `Demo scanner`; it only selects a member. Manual attendance works without hardware.

## Simplest integration approach to evaluate with the supplier
Choose a device whose vendor software can export matched attendance logs containing a stable device user ID and timestamp, or whose documented SDK can provide successful-match events. Ask the supplier to demonstrate the actual event/export before purchasing. A USB fingerprint sensor alone is not necessarily a complete attendance system. Do not assume a specific brand/model or SDK is supported.

1. Enroll fingers using the chosen device or vendor software.
2. Set its user ID in the member's `Future scanner user ID` field. This field is unique.
3. Implement a device-specific adapter once its documented interface is available.
4. The adapter must only send verified successful-match events, resolve scanner_id to a member, enforce the same freeze/expiry policy, preserve the device timestamp in Asia/Kolkata, deduplicate by member/day, and record method `Biometric`.
5. Authenticate any machine endpoint with a generated device secret and replay protection. Never accept an unauthenticated caller's `matched: true` claim. Do not expose owner login/session credentials to the device.

The current API deliberately rejects `Biometric` attendance: enabling an unverified endpoint would falsely label ordinary member-ID submissions as real fingerprint matches. Add the authenticated adapter and hardware acceptance tests together. Until then, use Manual or Demo scanner.

## Proposed normalized adapter output (not an active endpoint)
{ "eventId": "vendor-unique-event", "scannerUserId": "123", "matchedAt": "2026-09-07T02:12:18Z", "deviceId": "front-desk" }

Never store raw fingerprint images in this application. Template storage and enrollment consent are responsibilities of the selected hardware integration. Test valid, unknown, duplicate, frozen, expired, disconnected and offline/replayed events before enabling operational use.
