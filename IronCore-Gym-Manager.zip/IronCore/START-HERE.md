# IronCore Gym Manager 1.1.1 — tested source and demonstration records

## Explore the 24 fictional members

1. Install Node.js 24 or newer if it is not already installed.
2. Extract this entire ZIP into a new writable folder.
3. Double-click **Start-Demo.bat**. The first run installs the backend dependencies and needs internet.
4. Open **http://localhost:3001**. If the page opens before startup finishes, refresh it.
5. Create a **demo owner account** with your own username and a password of at least 10 characters. No credentials are bundled.

The demo uses its own `demo-data-store/gym.sqlite`. It does not open the normal gym database or your installed desktop app's data folder. Keep the terminal open while using it. Subsequent demo launches retain your edits. Use a fresh extracted folder if you want to start again.

The sample contains **24 fictional members, 5 plans, 51 payment records and 115 attendance records** in the supplied September 9, 2026 snapshot. Starting a new demo generates dates relative to its launch day. Names end in “Demo”, phones use `TEST-` placeholders, and scanner IDs use `DEMO-` placeholders. The small placeholder photos are fictional test images.

Explore Members → Profile to see each person's contact, plan, joining and renewal dates, status, scanner ID, payments and attendance. Other pages include Dashboard, Attendance, Payments, Due fees, Plans, Reports and Settings.

## Use or update the normal app

`Start-IronCore.bat` runs the browser-based source app at http://localhost:3000. The desktop source is included and `Build-Windows-App.bat` can build a Windows installer. **This ZIP does not contain a prebuilt EXE.** Windows and Electron behavior still need testing on Windows.

Before updating an existing installation, export its backup and keep your original installation/data folder. Extract this ZIP separately. Do not replace or delete an existing `data` folder. To move real records into another installation, use Settings → Restore backup with your own backup, then verify the records. Restore replaces gym records and preserves the destination's owner account.

`demo-records.json` is a restore-compatible fictional snapshot. Do not restore it into a gym database containing real records; use Start-Demo.bat instead.

## What was checked

**69/69 automated checks passed**, plus the original regression tests and a separate demo-launch check. See `TEST-REPORT.md` and `qa/results.json` for precise scope and results.

The tests exercise the real Express API and SQLite database, and the actual frontend JavaScript in a simulated DOM. They do not prove real-browser layout, native print/download dialogs, Windows installation, or biometric hardware compatibility.

To rerun after installing development dependencies:

```bash
npm ci
npm test
npm run test:full
```

For browser/demo use only, `npm ci --omit=dev` is enough. The full test suite requires the included development dependency jsdom.
