# IronCore Gym Manager 1.1.1 — test report

Tested on 9 September 2026 using Node.js 24.19.0 on Linux.

## Result

69 of 69 automated checks passed. The original backend regression suite also passed. A separate launch check verified the demo's 24 members, 51 payments, 115 attendance entries, five plans and zero bundled owner accounts.

The actual API and SQLite database were used in isolated temporary test directories. The actual `public/app.js` was executed in jsdom with HTTP requests sent to that API. FileReader uploads and JSON/CSV generation were exercised. Dialog, download and print adapters were simulated to verify the JavaScript handlers; operating-system dialogs were not tested.

## Coverage by page

| Page / area | Checked |
| --- | --- |
| Owner setup / login | Initial setup screen, credential validation, authenticated access, failed login, retry, cookie flags, rate limit, session expiry, logout and password change |
| Dashboard | Seeded member, attendance and scheduled-overdue totals; navigation and empty data |
| Members | All 24 seeded member details, search by name/phone/displayed ID, create/edit/cancel, photo upload/retention/size, profile histories, freeze/unfreeze/cancel, escaped text |
| Attendance | Manual and simulated check-in, duplicates, frozen/expired blocking, configurable expiry policy, explicit-expiry status, unknown/unconfigured hardware, modal feedback |
| Payments | All four methods, exact paise, date/amount validation, invalid-write rollback, member selection, renewal status, repeated-submit protection, histories and exports |
| Due fees | Overdue, Due today, This week and Upcoming filter membership |
| Plans | Create/edit, free plan, invalid duration/name and nonexistent plan rejection; new-member price and renewal date calculation |
| Reports | Explicit and date-based expired count, print-handler invocation, CSV actions; six monthly collection totals and the 14-day inactivity list |
| Settings | Gym details, expiry policy, password change, backup download, valid/invalid/cancelled restores, large backup and owner-session behavior |
| Persistence | Backup/restore roundtrip, malformed backup rejection, foreign-key rollback and restart persistence |
| Demo launcher | Separate database startup with fictional records and no pre-created owner |

## Fixes made

- Search recognizes the displayed `GM-0001` member ID.
- Cancel/navigation buttons explicitly use `type="button"`.
- New-member renewal dates follow the selected plan duration and joining date. Existing-member due dates remain explicit during edits.
- Invalid blank/null/boolean amounts and fractions smaller than one paise are rejected.
- Joining/due/payment dates are checked for the supported relationships.
- Photo uploads enforce the same 1 MB limit at the UI and backend and check allowed image signatures. Image decoding across browsers still needs visual verification.
- Missing plans, blank gym names and unsupported backup payment methods are rejected.
- Empty-plan backups are rejected to avoid an unusable membership form and inconsistent reseeding on restart.
- Authenticated restores accept backups up to 50 MB; other JSON requests retain the 3 MB cap. Errors identify malformed or oversized input.
- Attendance modal messages preserve duplicate/check-in results; modal errors remain visible inside the dialog.
- Member and payment modal submissions guard against rapid duplicate clicks; member upload captures the intended member ID before asynchronous reading.
- Reports include members explicitly marked Expired even if their due date is in the future; the recent-visit window uses today plus the preceding 13 days.
- CSV names identify the exported data type. Formula-prefix escaping also handles leading whitespace.
- Expired sessions return to login. Failed-login retries preserve the username, and successful login starts at Dashboard.
- Sign-out remains reachable in the narrow-screen CSS layout; muted text on dark panels has improved contrast. These CSS changes were reviewed but not visually tested.
- The browser launcher checks for Express, and the separate demo launcher preserves the normal database.

## Boundaries and remaining limitations

- The cloud browser could not reach the local app (`ERR_BLOCKED_BY_CLIENT`). No rendered browser screenshots or complete visual/responsive verification are claimed.
- Electron startup, Windows installer execution, desktop menus, single-instance focus, native dialogs and OS data-directory behavior were reviewed in source only. No prebuilt EXE is included.
- Print handler invocation passed; printed page layout and native PDF output were not verified. CSV/backup contents passed; the Electron Save dialog was not verified.
- Biometric attendance is still a labelled simulation. Live scanner enrollment, matching and device disconnection cannot be tested without a supported device and adapter.
- Payments are recorded receipts. Scheduled overdue fees are not a partial-payment balance ledger. Freeze does not automatically extend renewal dates. These are existing product limitations, not newly implemented features.
- Forgotten-password recovery is not implemented. Changing a password requires the current password.
- The current restore limit is 50 MB; larger databases need a future streaming/import approach. No high-volume concurrency, penetration test or performance benchmark is claimed.
- There are no member deletion, payment reversal or automatic reminder functions to test in this version.

## Reproduce

Use Node.js 24 or newer, run `npm ci`, then `npm test` and `npm run test:full`. Full tests create and delete their own temporary database and generate `qa/results.json`. Run `Start-Demo.bat` separately to explore the sample data.

## Individual checks

1. **PASS** — Fresh setup state
2. **PASS** — All private endpoints require owner session
3. **PASS** — UI fresh setup page and empty-account guidance
4. **PASS** — Setup rejects short credentials
5. **PASS** — Owner setup and secure cookie flags
6. **PASS** — Incorrect credentials rejected
7. **PASS** — Cross-origin writes rejected
8. **PASS** — 24 fictional members and histories imported
9. **PASS** — Backup excludes owner credentials
10. **PASS** — Member create/edit/photo/unique scanner link
11. **PASS** — Member validation: blank fields, status, missing plan, dates
12. **PASS** — Reject due date before joining date
13. **PASS** — Reject blank, null, boolean and sub-paise money
14. **PASS** — Reject non-image and oversized photos
15. **PASS** — Create and edit plan including free price
16. **PASS** — Reject invalid or missing plan updates
17. **PASS** — All four payment methods and exact paise storage
18. **PASS** — Invalid payment is atomic
19. **PASS** — Frozen payment without renewal preserves freeze; renewal activates
20. **PASS** — Manual check-in and duplicate deduplication
21. **PASS** — Demo attendance is labelled and real biometric rejected
22. **PASS** — Frozen and expired membership rules
23. **PASS** — Settings reject empty gym name
24. **PASS** — Restore malformed and invalid foreign keys roll back
25. **PASS** — Restore rejects empty plans and invalid payment method
26. **PASS** — Backup over 3 MB restores successfully
27. **PASS** — Password change checks current password and invalidates sessions
28. **PASS** — Sign-out invalidates session
29. **PASS** — Database persists across server restart
30. **PASS** — Login rate limit blocks repeated failures
31. **PASS** — UI dashboard totals match all seeded records
32. **PASS** — UI all eight navigation screens render
33. **PASS** — UI member search by name and phone
34. **PASS** — UI search using displayed GM-0001 ID
35. **PASS** — UI profile shows photo, payment and attendance histories
36. **PASS** — UI edit member saves updated contact
37. **PASS** — UI cancel never submits a form
38. **PASS** — UI joining date and selected plan calculate renewal date
39. **PASS** — UI add a new member
40. **PASS** — UI member photo upload is stored and preserved during edit
41. **PASS** — UI oversized photo reports error and keeps form
42. **PASS** — UI freeze and unfreeze
43. **PASS** — UI cancelled freeze leaves member unchanged
44. **PASS** — UI profile check-in and duplicate message
45. **PASS** — UI attendance modal preserves duplicate feedback
46. **PASS** — UI blocked attendance error remains in the modal
47. **PASS** — UI simulated scan and modal close
48. **PASS** — UI payment member switch updates amount and due date
49. **PASS** — UI payment submission records money and renews
50. **PASS** — UI rapid duplicate payment submit records once
51. **PASS** — UI every due-fee filter matches expected members
52. **PASS** — UI create and edit plan
53. **PASS** — UI reports correctly count explicitly expired future-due members
54. **PASS** — UI print action invokes print handler
55. **PASS** — UI CSV exports members/payments/attendance and quotes correctly
56. **PASS** — UI CSV neutralizes spreadsheet formula cells
57. **PASS** — UI backup download contains current gym records
58. **PASS** — UI settings save gym name and expiry policy
59. **PASS** — UI malformed restore reports error without losing records
60. **PASS** — UI cancelled restore keeps all records
61. **PASS** — UI invalid password change keeps user signed in
62. **PASS** — UI valid restore refreshes records
63. **PASS** — UI expired session returns to sign-in
64. **PASS** — UI login form handles rejection and successful sign-in
65. **PASS** — UI password change invalidates login
66. **PASS** — UI sign-out action returns to login
67. **PASS** — UI empty-state payment and attendance actions give useful guidance
68. **PASS** — UI member text is escaped instead of rendered as HTML
69. **PASS** — UI no uncaught DOM event errors
