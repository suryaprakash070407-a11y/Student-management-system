@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 24 or newer to build the installer.
 pause
 exit /b 1
)
call npm ci
if errorlevel 1 goto failed
call npm run dist:win
if errorlevel 1 goto failed
explorer "%~dp0dist"
echo Build complete. Run the Setup executable in dist to install IronCore.
pause
exit /b 0
:failed
echo Build failed. Please share the error shown above.
pause
exit /b 1
