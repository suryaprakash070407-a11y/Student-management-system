@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 24 or newer for source-mode startup.
 pause
 exit /b 1
)
if not exist node_modules\electron\dist\electron.exe (
 call npm ci
 if errorlevel 1 goto failed
)
call npm run desktop
if errorlevel 1 goto failed
exit /b 0
:failed
echo Startup failed. Please share the error above.
pause
exit /b 1
