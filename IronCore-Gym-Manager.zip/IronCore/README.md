**Start with [START-HERE.md](START-HERE.md) for the 24-member demo and [TEST-REPORT.md](TEST-REPORT.md) for verified scope.**

# Desktop edition 1.1.1

See **DESKTOP-START-HERE.md** for the desktop installer, record import and build instructions. The instructions below describe the retained browser/development mode.

# IronCore Gym Manager

Local desktop browser app using HTML, CSS, vanilla JavaScript, Node.js/Express and SQLite. No frontend framework or paid database service. Requires Node.js 24 or newer. The database uses Node's bundled SQLite module.

## Windows setup
1. Install Node.js 24 or newer.
2. Extract this entire ZIP into a permanent folder (for example Documents/IronCore).
3. Double-click Start-IronCore.bat. The first run downloads Express dependencies and needs internet. Alternatively run `npm ci` then `npm start` from this folder.
4. Open http://localhost:3000. If the browser opens before the server is ready, refresh it.
5. Create your owner username and password (10+ characters). There are no default credentials.
6. Keep the terminal window open while using the app. Close it to stop the server. The app is bound to this computer only.

## Included
- Owner setup/login, password change, sign-out; hashed passwords and HttpOnly sessions.
- Dashboard computed from actual records. Starts empty, with four editable plans.
- Searchable members; photo, plan, dates, fees, status and future scanner user ID.
- Profiles with payments and attendance; freeze/unfreeze and renewal.
- Manual attendance, labelled demo scanner attendance, one check-in per member per Indian calendar day, frozen/expired blocking.
- Payment recording with amount/date/method/next due date, plans, due filters.
- Reports, CSV exports for Excel, browser print/save as PDF.
- JSON backup/restore; automatic safety snapshot before restore. Owner credentials are intentionally excluded from backups.

## Fee meaning
Each member has a scheduled renewal fee and next due date. Overdue totals are renewal fees for past-due members (excluding frozen members), NOT an accounts-receivable ledger. The app does not calculate partial-payment balances. When recording a payment, explicitly review the next due date and whether to reactivate the membership. Freeze does not automatically extend due dates. Plan changes do not rewrite existing member fees.

## Data and backups
Data lives in `data/gym.sqlite` next to the server. Keep the application in a writable permanent folder. Use Settings → Download backup regularly and copy backups to another drive. Restoring replaces gym records and keeps a JSON safety copy in data/. Do not share backups: they contain member details/photos. Never delete data/ during updates. Password recovery: with server stopped, restore the whole application data folder from a secure earlier system backup; there is no bypass or recovery password.

## Verification
Run `npm test` for an isolated test database. Tests cover authentication, member creation, payments, duplicate attendance, freeze blocking, backup/restore and persistence after restart. No real scanner is integrated or tested. Use a small set of your own records to verify your gym's workflows before operational use. This build has not been tested on your Windows machine.

## Project files
- public/index.html, style.css, app.js: editable frontend
- server.js: Express API and SQLite schema
- data/: generated at first launch, never included in the download
- SCANNER.md: future hardware integration boundary

Local operation is intentional. Do not expose this development server to the internet or a shared network without adding HTTPS, deployment-grade authentication and a deployment review.
