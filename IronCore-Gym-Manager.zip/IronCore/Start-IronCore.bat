@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 24 or newer, then run this file again.
 pause
 exit /b 1
)
if not exist node_modules\express (
 call npm ci --omit=dev
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
start "" http://localhost:3000
node server.js
pause
