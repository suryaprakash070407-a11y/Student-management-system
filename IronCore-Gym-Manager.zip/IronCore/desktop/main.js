const {app,BrowserWindow,Menu,dialog,shell}=require('electron');
const path=require('node:path'),fs=require('node:fs');
app.setName('IronCore Gym');
let win,backend,quitting=false;
if(!app.requestSingleInstanceLock()){app.quit()}else{
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus()}});
app.whenReady().then(async()=>{
 const dataDir=path.join(app.getPath('userData'),'data');fs.mkdirSync(dataDir,{recursive:true});
 process.env.DATA_DIR=dataDir;process.env.PORT='0';
 try{
 backend=require('../server');
 await new Promise((resolve,reject)=>{if(backend.server.listening)resolve();else {backend.server.once('listening',resolve);backend.server.once('error',reject)}});
 const origin=`http://127.0.0.1:${backend.server.address().port}`;
 win=new BrowserWindow({width:1440,height:960,minWidth:850,minHeight:650,title:'IronCore Gym',backgroundColor:'#f4f4f6',icon:path.join(__dirname,'../build/icon.png'),show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,spellcheck:false}});
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-navigate',(e,url)=>{if(new URL(url).origin!==origin)e.preventDefault()});
 win.webContents.session.setPermissionRequestHandler((webContents,permission,callback)=>callback(false));
 win.webContents.session.on('will-download',(event,item)=>{const defaultPath=path.join(app.getPath('downloads'),path.basename(item.getFilename()));item.setSaveDialogOptions({defaultPath});});
 Menu.setApplicationMenu(Menu.buildFromTemplate([
 {label:'IronCore',submenu:[{label:'Open data folder',click:()=>shell.openPath(dataDir)},{type:'separator'},{role:'quit'}]},
 {label:'Edit',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},
 {label:'View',submenu:[{role:'reload'},{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'},{role:'togglefullscreen'}]},
 {label:'Help',submenu:[{label:'Import existing gym records',click:()=>dialog.showMessageBox(win,{type:'info',title:'Move your existing records',message:'In the old browser app, use Settings → Download backup. In this desktop app, create your owner login, then use Settings → Restore backup and select that JSON file. Your members, payments and attendance will be imported. The new owner login stays unchanged.'})},{label:'About IronCore',click:()=>dialog.showMessageBox(win,{type:'info',message:'IronCore Gym '+app.getVersion(),detail:'Local desktop app • SQLite\nReal biometric hardware is not configured.'})}]}]));
 await win.loadURL(origin);win.show();
 win.on('closed',()=>{win=null;app.quit()});
 backend.server.on('error',e=>{dialog.showErrorBox('IronCore server error',e.message);app.quit()});
 }catch(e){dialog.showErrorBox('IronCore could not start',e.stack||e.message);app.quit()}
});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{if(quitting)return;quitting=true;if(backend){backend.server.close();backend.db.close()}});
}
